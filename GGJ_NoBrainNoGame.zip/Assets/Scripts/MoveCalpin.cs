﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveCalpin : MonoBehaviour
{
    public Cursor cursor = null;
    // Transforms to act as start and end markers for the journey.
    public Transform startMarker;
    public Transform endMarker;

    // Movement speed in units per second.
    public float speed = 150.0f;

    // Time when the movement started.
    private float startTime;

    // Total distance between the markers.
    private float journeyLength;

    private bool isCalpinMove = false;
    private bool isShowHideCalpin = false;

    // Update is called once per frame
    void Update()
    {
        if (isCalpinMove)
        {
            if (isShowHideCalpin)
            {
                // Distance moved equals elapsed time times speed..
                float distCovered = (Time.time - startTime) * speed;

                // Fraction of journey completed equals current distance divided by total distance.
                float fractionOfJourney = distCovered / journeyLength;

                // Set our position as a fraction of the distance between the markers.
                transform.position = Vector3.Lerp(startMarker.position, endMarker.position, fractionOfJourney);

                if (transform.position == endMarker.position)
                {
                    isCalpinMove = false;
                }
            }
            else if (!isShowHideCalpin)
            {
                // Distance moved equals elapsed time times speed..
                float distCovered = (Time.time - startTime) * speed;

                // Fraction of journey completed equals current distance divided by total distance.
                float fractionOfJourney = distCovered / journeyLength;

                // Set our position as a fraction of the distance between the markers.
                transform.position = Vector3.Lerp(endMarker.position, startMarker.position, fractionOfJourney);
                if (transform.position == startMarker.position)
                {
                    isCalpinMove = false;
                }
            }
        }
    }

    public void ShowHideCalpin()
    {
        if (!isCalpinMove)
        {
            isShowHideCalpin = !isShowHideCalpin;
            if (isShowHideCalpin)
            {
                isCalpinMove = true;
                // Keep a note of the time the movement started.
                startTime = Time.time;

                // Calculate the journey length.
                journeyLength = Vector3.Distance(endMarker.position, startMarker.position);
            }
            else if (!isShowHideCalpin)
            {
                isCalpinMove = true;
                // Keep a note of the time the movement started.
                startTime = Time.time;

                // Calculate the journey length.
                journeyLength = Vector3.Distance(startMarker.position, endMarker.position);
                cursor.isCalpinOpen = false;
            }
        }
    }
}
